﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CST.ViewModel
{
    public class SECview
    {
        public int id { get; set; }
        public string Sname { get; set; }
        public string Cname { get; set; }
    }
}
